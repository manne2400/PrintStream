import { generateLicenseKey } from '../../src/utils/license';
import express from 'express';
import path from 'path';

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const port = 3000;

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/generate', (req, res) => {
  const { days, customerId } = req.body;
  
  try {
    const licenseKey = generateLicenseKey(Number(days), customerId);
    res.json({ success: true, licenseKey });
  } catch (error) {
    res.status(400).json({ success: false, error: 'Invalid input' });
  }
});

app.listen(port, () => {
  console.log(`License admin tool running at http://localhost:${port}`);
}); 